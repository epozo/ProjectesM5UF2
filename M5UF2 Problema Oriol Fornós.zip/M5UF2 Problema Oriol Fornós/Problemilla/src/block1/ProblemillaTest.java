package block1;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
class ProblemillaTest {
		
	private int num1;
	private int num2;
	private int num3;
	private int resul;
	
	public ProblemillaTest(int num1, int num2, int num3, int resul) {
		this.num1 = num1;
		this.num2 = num2;
		this.num3 = num3;
		this.resul = resul;
	}
	
	@Parameters
	public static Collection<Object[]> numeros() {
		return Arrays.asList(new Object[][] {
			{7, 4, 10, 4},
			{2, 3, 10, 0},
			{3, 3, 10, 0},
			{6, 5, 3, 2},
			{23, 25, 100, 0},
			{7, 4, 10, 6},
			{7, 4, 10, 6},
			{7, 4, 10, 6},
			{7, 4, 10, 6},
			{3, 3, 15, 0},
			{3, 3, 17, 0},
		});
		
	}
	
	@Test
	void testResolucio() {
		int res = Problemilla.resolucio(num1, num2, num3);
		assertEquals(resul, res);
		/**
		 * Suma els dos nombres i afegeix 1 (descripci� curta)       
		 * <p>
		 * Suma els dos nombres proporcionats. Despr�s de sumar-los    
		 * afegeix 1 a la resposta. (descripci� llarga, opcional)
		 * <p>
		 * Si voleu posar m�s explicaci� les podeu anar posant
		 * Com veieu els tags html funcionen en javadoc
		 *
		 * @param  int num1: Velocitat del arquer al disparar           
		 * @param  int num2: Velocitat dels soldats
		 * @param int num3: Mesura de la escala
		 * @param int resul: Total de soldats necesaris per escalar la escala.
		 * @return Retorna el numero de casos de proba juntament amb els seus resultats per saber si tot esta b�.
		 */
	}

}
