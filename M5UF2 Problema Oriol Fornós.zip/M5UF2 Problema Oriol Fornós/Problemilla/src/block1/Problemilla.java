package block1;

/* 
 *@author: Oriol Forn�s Cun� 
 * IES Sabadell
 * 1/3/2018
 * Ex: Asalt al castell
 */
import java.util.Scanner;

public class Problemilla {
	static Scanner reader = new Scanner(System.in);

	public static void main(String[] args) {
		int esc = 0; // Varaible del tamany de la escala
		int s = 0; // Variable de la velocitat del soldat
		int a = 0; // Variable de la velocitat del arquer
		int res = 0;
		int opcio = 0;

		opcio = reader.nextInt();
		while (opcio != 0) {
			res = resolucio(a, s, esc);
			opcio--;
			if(res != 0) {
			System.out.println(res);
			}
		}
	}

	public static int resolucio(int a, int s, int esc) {
		int auxs = 0; // auxiliar de la velocitat del soldat
		int cont = 0; // Variable de quants metres porten els soldats
		int conts = 0; // Variable de quants soldats han escalat la escala fins el moment, comen�a en 1 perque sempre comen�ara a escalar com a minim 1 soldat.
		boolean end2 = false; // per sortir del bucle

		a = reader.nextInt(); // introdueix la velocitat del arquer
		s = reader.nextInt(); // introdueix la velocitat del soldat (per metre)
		esc = reader.nextInt(); // introdueix els metres de la escala
		auxs = s;
		if (s < a) { // si la velcoitat del soldat es menor que la del arquer entrara en el bucle
			conts++;
			while (end2 == false) {
				if (a > s) { // Mentres que la suma del temps per metre sigui menor a la velocitat del arquer
								// ho seguira fent
					s = s + auxs; // suma el temps que fa el soldat per metre
					cont++; // conta quants metres ha fet el soldat
				} else {
					s = auxs; // reseteja els segons del soldat per que ho torni a fer
					conts++; // conta les persones que necesitara per conseguir-ho
				}
				if (cont >= esc) {
					end2 = true;
				}
			}
		} else { // Si la velocitat del soldat es major o igual que la del arquer no podran
					// conseguir-ho mai
			System.out.println("INCORRECTE");
		}
		if (end2 == true) {
			return conts;
		}

		return conts;
	}
}
