package ProblemaComentado;

import java.util.Scanner;
/**
 * <h1>clase Empleado, se utiliza para crear y leer empleados de una BD </h1>
 * 
 * Busca informaci�n de Javadoc en <a href="http://www.google.com">GOOGLE</a>
 * @see <a href="http://www.google.com"b >Google</a>
 * @version 1-2017
 * @author Jose Maria C�vico
 * @since 1-3-2018
 */

public class soluci�_comentada {

	static Scanner reader = new Scanner (System.in);

/**
 * M�tode public que es tracta d'introduir un n�mero que es representara en hores i a partir de les hores el programa mostrar� la conversi� en diferents medides. 	
 * @param args t�tol del m�tode p�blic
 * 
 *   	
 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		

		float segundos, minuts, hora, dia, any, milisegons, setmanes, mesos,trimestres, quadrimestre, decadas, segles;
		

		hora = reader.nextFloat();

		minuts = hora * 60;

		segundos = minuts / 60;

		dia = hora / 24;
 
		milisegons = segundos * 1000;
		
		any = dia / 365;
		
		setmanes = dia / 7;
		
		mesos = dia / 30;
		
		quadrimestre = mesos / 4;
		
		trimestres = mesos / 3 ;
		
		decadas = any / 10;
		
		segles = decadas / 10;

		
		System.out.println("Els milisegons s�n " + milisegons);
		System.out.println("Els segons s�n " + segundos);
		System.out.println("Els minuts s�n " + minuts);
		System.out.println("Les hores s�n " + hora);
		System.out.println("Els dies s�n " + dia);
		System.out.println("Les setmanes s�n " + setmanes);
		System.out.println("Els mesos s�n " + mesos);
		System.out.println("Els trimestres s�n " + trimestres);
		System.out.println("Els quadrimestres s�n " + quadrimestre);
		System.out.println("Els anys s�n " + any);
		System.out.println("Els sigles s�n " + segles);
	}

}
