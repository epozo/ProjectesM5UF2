package problema;


import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
	
@RunWith(Parameterized.class)
public static class act1 {


	private int num1;
	private int resul;
	
	public CalculadoraTestSuma (int num1, int resul) {
		this.num1 = num1;
		this.resul = resul;
	}
	
	@Parameters
	public static Collection<Object[]> numeros() {
		return Arrays.asList(new Object[][] {
			{2160, 36.0},
			{2880, 48.0},
			{4320, 72.0}
		});
		
	}
	@Test
	public void testSuma() {
		int res = act1.main(num1);
		assertEquals(resul,  res);
	}
}
