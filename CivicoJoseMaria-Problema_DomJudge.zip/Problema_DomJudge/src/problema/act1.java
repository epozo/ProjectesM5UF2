package problema;

import java.util.Scanner;

public class act1 {
	
	static Scanner reader = new Scanner (System.in);
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		float segundos;
		float minuts, hora, dia, a�o, milisegons, setmanes, mesos,trimestres, quadrimestre, decadas, segles;
		
		hora = reader.nextFloat();
		
		minuts = hora / 60;
		segundos = minuts * 60;
		dia = hora / 24;
		milisegons = segundos * 1000;
		a�o = dia / 365;
		setmanes = dia / 7;
		mesos = dia / 30;
		quadrimestre = mesos / 4;
		trimestres = mesos / 3 ;
		decadas = a�o / 10;
		segles = decadas / 10;

		
		System.out.println("Els milisegons s�n " + milisegons);
		System.out.println("Els segons s�n " + segundos);
		System.out.println("Els minuts s�n " + minuts);
		System.out.println("Les hores s�n " + hora);
		System.out.println("Els dies s�n " + dia);
		System.out.println("Les setmanes s�n " + setmanes);
		System.out.println("Els mesos s�n " + mesos);
		System.out.println("Els trimestres s�n " + trimestres);
		System.out.println("Els quadrimestres s�n " + quadrimestre);
		System.out.println("Els anys s�n " + a�o);
		System.out.println("Els sigles s�n " + segles);
	}

}
